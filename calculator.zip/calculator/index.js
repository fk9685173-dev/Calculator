const display = document.getElementById("display");

function numDisplay(input){
    display.value += input;
}
function clearDisplay(){
    display.value = "";
}
function  equalDisplay(){
   display.value = eval(display.value);
}
